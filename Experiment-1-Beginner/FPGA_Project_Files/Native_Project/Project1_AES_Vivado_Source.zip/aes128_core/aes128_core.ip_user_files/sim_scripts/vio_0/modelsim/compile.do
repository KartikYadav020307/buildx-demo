vlib modelsim_lib/work
vlib modelsim_lib/msim

vlib modelsim_lib/msim/xil_defaultlib

vmap xil_defaultlib modelsim_lib/msim/xil_defaultlib

vlog -work xil_defaultlib  -incr -mfcu  "+incdir+../../../../../../../../../Xilinx/2025.1.1/Vivado/data/rsb/busdef" "+incdir+../../../../aes128_core.gen/sources_1/ip/vio_0/hdl/verilog" "+incdir+../../../../aes128_core.gen/sources_1/ip/vio_0/hdl" \
"../../../../aes128_core.gen/sources_1/ip/vio_0/sim/vio_0.v" \


vlog -work xil_defaultlib \
"glbl.v"

